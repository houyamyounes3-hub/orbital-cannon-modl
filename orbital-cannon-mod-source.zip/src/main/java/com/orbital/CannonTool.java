package com.orbital;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;

public class CannonTool extends Item {
    private static final ResourceLocation CANNON = ResourceLocation.fromNamespaceAndPath("orbital", "cannon");

    public CannonTool(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level instanceof ServerLevel server) {
            // Center the 32x32 build on the clicked block, sitting on top of it.
            BlockPos origin = context.getClickedPos().above().offset(-16, 0, -16);
            var template = server.getStructureManager().get(CANNON);
            if (template.isPresent()) {
                template.get().placeInWorld(server, origin, origin, new StructurePlaceSettings(), server.getRandom(), 2);
                if (context.getPlayer() != null) {
                    context.getPlayer().displayClientMessage(Component.literal("Orbital strike cannon placed."), true);
                }
            } else if (context.getPlayer() != null) {
                context.getPlayer().displayClientMessage(Component.literal("Cannon structure not found."), true);
            }
        }
        return InteractionResult.SUCCESS;
    }
}
