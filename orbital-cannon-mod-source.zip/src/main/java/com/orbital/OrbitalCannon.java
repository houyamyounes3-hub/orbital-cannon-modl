package com.orbital;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public class OrbitalCannon implements ModInitializer {
    public static final String MOD_ID = "orbitalcannon";
    public static Item CANNON_TOOL;

    @Override
    public void onInitialize() {
        ResourceKey<Item> key = ResourceKey.create(
            Registries.ITEM, ResourceLocation.fromNamespaceAndPath(MOD_ID, "cannon_tool"));
        CANNON_TOOL = Registry.register(
            BuiltInRegistries.ITEM, key,
            new CannonTool(new Item.Properties().setId(key).stacksTo(1)));

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
            .register(entries -> entries.accept(CANNON_TOOL));
    }
}
